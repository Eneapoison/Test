<?php return
    array( 'dependencies' =>
        array(
            'wp-blocks',
            'wp-element',
            'wp-polyfill'
        ),
        'version' => '0.1'
    );
